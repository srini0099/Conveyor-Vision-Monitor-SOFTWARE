import pandas as pd
from src.analytics import summarize_detections, confidence_report

def test_summary():
    df = pd.DataFrame({
        "frame_id": [1, 2, 3],
        "timestamp": [
            "2026-09-07T06:00:00",
            "2026-09-07T06:00:01",
            "2026-09-07T06:00:02"
        ],
        "confidence": [0.8, 0.9, 1.0],
        "crossed_line": [0, 1, 1]
    })

    result = summarize_detections(df)

    assert result["total_objects"] == 3
    assert result["counted_over_line"] == 2
    assert result["frames_processed"] == 3

def test_confidence():
    df = pd.DataFrame({"confidence": [0.8, 0.9, 1.0]})
    result = confidence_report(df)
    assert result["mean"] == 0.9
