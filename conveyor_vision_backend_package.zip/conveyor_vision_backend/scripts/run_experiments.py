import sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.analytics import summarize_detections, confidence_report, alert_rules

DATA = ROOT / "data" / "processed" / "synthetic_detections.csv"
REPORT = ROOT / "reports"
REPORT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)

summary = summarize_detections(df)
confidence = confidence_report(df)
alerts = alert_rules(df)

report = {
    "dataset_rows": len(df),
    "summary": summary,
    "confidence": confidence,
    "alerts": alerts
}

pd.DataFrame([summary]).to_csv(REPORT / "summary_metrics.csv", index=False)
pd.DataFrame([confidence]).to_csv(REPORT / "confidence_metrics.csv", index=False)
pd.DataFrame(alerts).to_csv(REPORT / "alerts.csv", index=False)

print("=== EXPERIMENT RESULTS ===")
print(report)
