from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "reports"

summary = pd.read_csv(REPORT / "summary_metrics.csv")
confidence = pd.read_csv(REPORT / "confidence_metrics.csv")

with open(REPORT / "experiment_report.txt", "w") as f:
    f.write("CONVEYOR VISION MONITOR - EXPERIMENT REPORT\n")
    f.write("=" * 50 + "\n\n")
    f.write("Summary Metrics\n")
    f.write(summary.to_string(index=False))
    f.write("\n\nConfidence Metrics\n")
    f.write(confidence.to_string(index=False))
    f.write("\n")

print(f"Report created: {REPORT / 'experiment_report.txt'}")
