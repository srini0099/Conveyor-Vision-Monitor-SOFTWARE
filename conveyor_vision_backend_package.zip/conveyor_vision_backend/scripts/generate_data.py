import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.detector_simulator import generate_synthetic_detections

output = ROOT / "data" / "processed"
output.mkdir(parents=True, exist_ok=True)

df = generate_synthetic_detections(
    n_frames=1200,
    objects_per_frame=2,
    seed=42
)

path = output / "synthetic_detections.csv"
df.to_csv(path, index=False)

print(f"Generated {len(df)} synthetic detections.")
print(f"Saved to: {path}")
