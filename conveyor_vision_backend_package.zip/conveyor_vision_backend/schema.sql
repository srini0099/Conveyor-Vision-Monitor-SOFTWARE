CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_name TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    frames_processed INTEGER DEFAULT 0,
    total_objects INTEGER DEFAULT 0,
    counted_over_line INTEGER DEFAULT 0,
    avg_confidence REAL DEFAULT 0,
    status TEXT DEFAULT 'IDLE'
);

CREATE TABLE IF NOT EXISTS detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    frame_id INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    object_type TEXT NOT NULL,
    confidence REAL NOT NULL,
    x1 REAL,
    y1 REAL,
    x2 REAL,
    y2 REAL,
    crossed_line INTEGER DEFAULT 0,
    FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    severity TEXT NOT NULL,
    alert_type TEXT NOT NULL,
    message TEXT NOT NULL,
    resolved INTEGER DEFAULT 0
);
