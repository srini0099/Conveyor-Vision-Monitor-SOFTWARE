# Conveyor Vision Monitor — Backend & Experiment Package

A simple, professional backend/research package for the Conveyor Vision Monitor web application.

## Purpose
This package supports a conveyor-belt computer-vision monitoring dashboard with:
- synthetic detection data
- object counting
- line-crossing events
- frame/session metrics
- model confidence statistics
- experiment tracking
- evaluation metrics
- FastAPI backend endpoints
- SQLite storage
- CSV export
- Google Colab-friendly experiments

> The included data is synthetic/demo data. Replace it with real camera detections when available.

## Project structure

```text
conveyor_vision_backend/
├── data/
│   ├── raw/
│   ├── processed/
│   └── sample_detections.csv
├── experiments/
│   ├── 01_data_exploration.ipynb
│   ├── 02_detection_metrics.ipynb
│   └── 03_line_crossing_analysis.ipynb
├── src/
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── analytics.py
│   ├── detector_simulator.py
│   └── api.py
├── scripts/
│   ├── generate_data.py
│   ├── run_experiments.py
│   └── export_report.py
├── tests/
│   └── test_analytics.py
├── reports/
├── requirements.txt
├── schema.sql
└── README.md
```

## Quick start in Google Colab

Upload/extract this folder, then run:

```python
!pip install -r requirements.txt
!python scripts/generate_data.py
!python scripts/run_experiments.py
```

To start the API locally:

```python
!uvicorn src.api:app --host 0.0.0.0 --port 8000
```

## Main API endpoints

- `GET /health`
- `GET /api/overview`
- `GET /api/session`
- `GET /api/detections`
- `GET /api/analytics`
- `GET /api/alerts`
- `GET /api/performance`

## Recommended workflow

Camera/video
→ object detection
→ tracking
→ line-crossing logic
→ event storage
→ analytics
→ dashboard

## Important

This package is designed as a backend/demo evidence package for the existing Conveyor Vision Monitor interface. It does not claim to reconstruct private source code from the deployed website.
