import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_synthetic_detections(
    n_frames=600,
    objects_per_frame=2,
    seed=42
):
    rng = np.random.default_rng(seed)
    start = datetime(2026, 9, 7, 6, 0, 0)
    rows = []

    for frame in range(1, n_frames + 1):
        timestamp = start + timedelta(seconds=frame)

        for obj in range(objects_per_frame):
            confidence = float(np.clip(rng.normal(0.90, 0.07), 0.35, 0.99))
            x1 = float(rng.integers(20, 500))
            y1 = float(rng.integers(80, 300))
            width = float(rng.integers(70, 150))
            height = float(rng.integers(60, 130))

            crossed = int(rng.random() < 0.08)

            rows.append({
                "session_id": 1,
                "frame_id": frame,
                "timestamp": timestamp.isoformat(),
                "object_type": "box",
                "confidence": round(confidence, 4),
                "x1": x1,
                "y1": y1,
                "x2": x1 + width,
                "y2": y1 + height,
                "crossed_line": crossed
            })

    return pd.DataFrame(rows)
