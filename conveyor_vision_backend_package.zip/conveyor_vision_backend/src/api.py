from fastapi import FastAPI
from .database import initialize_database
from .analytics import summarize_detections, confidence_report, alert_rules
from .detector_simulator import generate_synthetic_detections

app = FastAPI(
    title="Conveyor Vision Monitor API",
    version="1.0.0",
    description="Backend API for conveyor computer-vision monitoring."
)

initialize_database()

# Demo data loaded in memory for a simple Colab/local demonstration.
DF = generate_synthetic_detections()

@app.get("/health")
def health():
    return {"status": "ok", "service": "conveyor-vision-monitor"}

@app.get("/api/overview")
def overview():
    return summarize_detections(DF)

@app.get("/api/session")
def session():
    summary = summarize_detections(DF)
    return {
        "session": "Demo conveyor inspection",
        "status": "IDLE",
        "frames_processed": summary["frames_processed"],
        "model_confidence": summary["avg_confidence"],
        "total_objects": summary["total_objects"],
        "counted_over_line": summary["counted_over_line"]
    }

@app.get("/api/detections")
def detections(limit: int = 100):
    return DF.head(max(1, min(limit, 1000))).to_dict(orient="records")

@app.get("/api/analytics")
def analytics():
    return {
        "summary": summarize_detections(DF),
        "confidence": confidence_report(DF)
    }

@app.get("/api/alerts")
def alerts():
    return {"alerts": alert_rules(DF)}

@app.get("/api/performance")
def performance():
    summary = summarize_detections(DF)
    return {
        "frames_processed": summary["frames_processed"],
        "objects_detected": summary["total_objects"],
        "objects_per_frame": round(
            summary["total_objects"] / max(summary["frames_processed"], 1), 3
        ),
        "count_rate_per_min": summary["count_rate_per_min"]
    }
