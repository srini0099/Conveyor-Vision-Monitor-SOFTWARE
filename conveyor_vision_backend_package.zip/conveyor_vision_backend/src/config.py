from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
REPORT_DIR = BASE_DIR / "reports"
DB_PATH = BASE_DIR / "conveyor_vision.db"

CONFIDENCE_THRESHOLD = 0.50
LINE_X = 300
