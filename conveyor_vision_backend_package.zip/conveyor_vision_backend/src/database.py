import sqlite3
from pathlib import Path
from .config import DB_PATH, BASE_DIR

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def initialize_database():
    schema = (BASE_DIR / "schema.sql").read_text()
    with get_connection() as conn:
        conn.executescript(schema)
        conn.commit()
