import pandas as pd
import numpy as np

def summarize_detections(df: pd.DataFrame) -> dict:
    if df.empty:
        return {
            "total_objects": 0,
            "counted_over_line": 0,
            "frames_processed": 0,
            "avg_confidence": 0.0,
            "count_rate_per_min": 0.0
        }

    frames = int(df["frame_id"].nunique())
    total = int(len(df))
    crossed = int(df["crossed_line"].sum())
    confidence = float(df["confidence"].mean())

    duration_seconds = 0
    if "timestamp" in df.columns:
        ts = pd.to_datetime(df["timestamp"])
        if len(ts) > 1:
            duration_seconds = max((ts.max() - ts.min()).total_seconds(), 1)

    rate = crossed / (duration_seconds / 60) if duration_seconds else 0

    return {
        "total_objects": total,
        "counted_over_line": crossed,
        "frames_processed": frames,
        "avg_confidence": round(confidence, 4),
        "count_rate_per_min": round(rate, 2)
    }

def confidence_report(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"mean": 0, "median": 0, "min": 0, "max": 0}

    values = df["confidence"].astype(float)
    return {
        "mean": round(float(values.mean()), 4),
        "median": round(float(values.median()), 4),
        "min": round(float(values.min()), 4),
        "max": round(float(values.max()), 4)
    }

def alert_rules(df: pd.DataFrame) -> list:
    alerts = []
    if df.empty:
        return alerts

    avg = df["confidence"].mean()
    low_conf = (df["confidence"] < 0.50).sum()

    if avg < 0.70:
        alerts.append({
            "severity": "warning",
            "type": "LOW_MODEL_CONFIDENCE",
            "message": f"Average model confidence is {avg:.1%}."
        })

    if low_conf >= 5:
        alerts.append({
            "severity": "warning",
            "type": "MULTIPLE_LOW_CONFIDENCE",
            "message": f"{low_conf} detections are below the confidence threshold."
        })

    return alerts
