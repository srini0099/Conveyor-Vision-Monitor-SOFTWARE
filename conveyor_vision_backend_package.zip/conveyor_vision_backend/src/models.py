from pydantic import BaseModel
from typing import Optional

class Detection(BaseModel):
    session_id: int
    frame_id: int
    timestamp: str
    object_type: str
    confidence: float
    x1: float = 0
    y1: float = 0
    x2: float = 0
    y2: float = 0
    crossed_line: int = 0

class Session(BaseModel):
    session_name: str
    started_at: str
    ended_at: Optional[str] = None
    frames_processed: int = 0
    total_objects: int = 0
    counted_over_line: int = 0
    avg_confidence: float = 0
    status: str = "IDLE"
