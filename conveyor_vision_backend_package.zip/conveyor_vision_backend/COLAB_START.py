# Copy/paste these commands into Google Colab
!pip install -q -r requirements.txt
!python scripts/generate_data.py
!python scripts/run_experiments.py
!python scripts/export_report.py

# Optional API:
# !uvicorn src.api:app --host 0.0.0.0 --port 8000
